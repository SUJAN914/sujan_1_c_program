const form = document.getElementById('attendanceForm');
const table = document.getElementById('attendanceTable').getElementsByTagName('tbody')[0];

form.addEventListener('submit', function(e) {
  e.preventDefault();

  const name = document.getElementById('name').value;
  const classValue = document.getElementById('class').value;
  const status = document.getElementById('status').value;
  const time = new Date().toLocaleTimeString();

  const newRow = table.insertRow();
  newRow.innerHTML = `
    <td>${name}</td>
    <td>${classValue}</td>
    <td>${status}</td>
    <td>${time}</td>
  `;

  form.reset();
});